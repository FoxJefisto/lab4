module Main where
import Data.Matrix
import Control.Parallel.Strategies
import System.Clock
import Control.DeepSeq

-- | Split a matrix into four quadrants
splitMatrix :: Matrix Int -> (Matrix Int, Matrix Int, Matrix Int, Matrix Int)
splitMatrix mtrx = (c11, c12, c21, c22)
    where
        n = nrows mtrx
        m = n `div` 2
        (c11, c12, c21, c22) = splitBlocks m m mtrx

-- | Combine four matrices into one
combineMatrix :: (Matrix Int, Matrix Int, Matrix Int, Matrix Int) -> Matrix Int
combineMatrix (c11, c12, c21, c22) = (c11 <|> c12) <-> (c21 <|> c22)

-- | Strassen's matrix multiplication algorithm
strassen :: Matrix Int -> Matrix Int -> Matrix Int
strassen a b 
    | n < 32 = multStd a b
    | otherwise = combineMatrix (c11, c12, c21, c22)
    where
        n = nrows a
        (a11, a12, a21, a22) = splitMatrix a
        (b11, b12, b21, b22) = splitMatrix b

        (c11, c12, c21, c22) = runEval $ do
            p1 <- rpar $ strassen (a11 + a22) (b11 + b22)
            p2 <- rpar $ strassen (a21 + a22) b11
            p3 <- rpar $ strassen a11 (b12 - b22)
            p4 <- rpar $ strassen a22 (b21 - b11)
            p5 <- rpar $ strassen (a11 + a12) b22
            p6 <- rpar $ strassen (a21 - a11) (b11 + b12)
            p7 <- rpar $ strassen (a12 - a22) (b21 + b22)
            rseq p1
            rseq p2
            rseq p3
            rseq p4
            rseq p5
            rseq p6
            rseq p7
            rc11 <- rpar (p1 + p4 - p5 + p7)
            rc12 <- rpar (p3 + p5)
            rc21 <- rpar (p2 + p4)
            rc22 <- rpar (p1 - p2 + p3 + p6)
            rseq rc11
            rseq rc12
            rseq rc21
            rseq rc22
            return (rc11, rc12, rc21, rc22)

main :: IO ()
main = do
    let size = 128
    let a = matrix size size $ \(i,j) -> 4
    let b = matrix size size $ \(i,j) -> 4
    timeStart <- getTime Monotonic
    print(strassen a b)
    timeEnd <- getTime Monotonic
    -- print(result)
    let timeRun = timeEnd - timeStart
    print(sec timeRun)
    return ()
